package co.edu.unisabana.parcial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParcialApplicationTests {

	@Test
	void contextLoads() {
	}

}
